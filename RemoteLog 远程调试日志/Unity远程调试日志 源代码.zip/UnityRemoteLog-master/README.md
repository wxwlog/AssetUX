# UnityRemoteLog
将Unity的Log转发到一个窗口上，方便查找Android、iOS版本的LOG
